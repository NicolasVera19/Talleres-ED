package parte3;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Crear la lista de tareas pendientes
        List<String> listaTareas = new ArrayList<>();

        // Menú de opciones para gestionar las tareas
        while (true) {
            System.out.println("\n--- Gestión de Tareas ---");
            System.out.println("1. Agregar tarea");
            System.out.println("2. Eliminar tarea completada");
            System.out.println("3. Mostrar todas las tareas pendientes");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    // Agregar una tarea
                    System.out.print("Ingrese la tarea: ");
                    String tarea = sc.nextLine();
                    listaTareas.add(tarea);
                    System.out.println("Tarea agregada.");
                    break;
                case 2:
                    // Eliminar una tarea completada
                    System.out.print("Ingrese el número de la tarea completada para eliminar: ");
                    int indice = sc.nextInt();
                    sc.nextLine(); // Limpiar el buffer
                    if (indice > 0 && indice <= listaTareas.size()) {
                        listaTareas.remove(indice - 1);
                        System.out.println("Tarea eliminada.");
                    } else {
                        System.out.println("Número de tarea no válido.");
                    }
                    break;
                case 3:
                    // Mostrar todas las tareas pendientes
                    System.out.println("\nTareas pendientes:");
                    if (listaTareas.isEmpty()) {
                        System.out.println("No hay tareas pendientes.");
                    } else {
                        for (int i = 0; i < listaTareas.size(); i++) {
                            System.out.println((i + 1) + ". " + listaTareas.get(i));
                        }
                    }
                    break;
                case 4:
                    // Salir del programa
                    System.out.println("Saliendo...");
                    sc.close();
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}

