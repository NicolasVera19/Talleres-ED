package Mundo;


// Taller clase 1 parte 1 y 2, Nicolas Fernando Vera Vizcaya-2220221004

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Crear la lista de personas
        List<Persona> listaPersonas = new ArrayList<>();

        // Agregar personas a la lista
        listaPersonas.add(new Persona("Julian Silva"));
        listaPersonas.add(new Persona("Jorge Botero"));
        listaPersonas.add(new Persona("Sebastian Clavijo"));
        listaPersonas.add(new Persona("Juan Perea"));
        listaPersonas.add(new Persona("Vladimir Espinosa"));

        //Buscar un nombre en la lista
        System.out.print("Ingrese el nombre que desea buscar: ");
        String nombreBuscar = sc.nextLine();
        boolean encontrado = false;
        for (Persona persona : listaPersonas) {
            if (persona.getNombre().equalsIgnoreCase(nombreBuscar)) {
                encontrado = true;
                break;
            }
        }
        if (encontrado) {
            System.out.println("El nombre '" + nombreBuscar + "' fue encontrado en la lista.");
        } else {
            System.out.println("El nombre '" + nombreBuscar + "' no fue encontrado en la lista.");
        }

        //Agregar un nuevo nombre si no está ya en la lista
        System.out.print("Ingrese un nuevo nombre para agregar a la lista: ");
        String nombreNuevo = sc.nextLine();
        encontrado = false;
        for (Persona persona : listaPersonas) {
            if (persona.getNombre().equalsIgnoreCase(nombreNuevo)) {
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            listaPersonas.add(new Persona(nombreNuevo));
            System.out.println("El nombre '" + nombreNuevo + "' ha sido agregado a la lista.");
        } else {
            System.out.println("El nombre '" + nombreNuevo + "' ya está en la lista, no se agregó.");
        }

        // Imprimir la lista actualizada
        System.out.println("\nLista actualizada:");
        for (Persona persona : listaPersonas) {
            System.out.println(persona.getNombre());
        }

        // Eliminar un nombre de la lista
        System.out.print("\nIngrese el nombre que desea eliminar de la lista: ");
        String nombreEliminar = sc.nextLine();
        Persona personaAEliminar = null;
        for (Persona persona : listaPersonas) {
            if (persona.getNombre().equalsIgnoreCase(nombreEliminar)) {
                personaAEliminar = persona;
                break;
            }
        }
        if (personaAEliminar != null) {
            listaPersonas.remove(personaAEliminar);
            System.out.println("El nombre '" + nombreEliminar + "' ha sido eliminado de la lista.");
        } else {
            System.out.println("El nombre '" + nombreEliminar + "' NO fue encontrado en la lista, no se eliminó.");
        }

        // Imprimir la lista después de la eliminación
        System.out.println("\nLista después de la eliminación:");
        for (Persona persona : listaPersonas) {
            System.out.println(persona.getNombre());
        }

        sc.close();
    }
}
